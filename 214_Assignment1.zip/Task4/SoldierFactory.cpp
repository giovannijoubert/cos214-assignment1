#include "SoldierFactory.h"
#include <iostream>

SoldierFactory::SoldierFactory(){}
SoldierFactory::~SoldierFactory(){}
