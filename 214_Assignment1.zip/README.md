# cos214-assignment1
 implement the Template Method design pattern; • implement the Factory Method design pattern • implement the Prototype design pattern; • implement the Memento pattern;
